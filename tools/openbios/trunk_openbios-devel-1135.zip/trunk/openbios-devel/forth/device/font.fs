\ tag: 8x16 bitmap font
\ 
\ Terminus font 
\ 
\ The Terminus Font is developed by and is a property 
\ of Dimitar Toshkov Zhekov <jimmy@is-vn.bg>
\ 
\ See the file "COPYING" for further information about
\ the copyright and warranty status of this work.
\ 

\ encode-file romfont.bin
\ drop value (romfont-8x16)

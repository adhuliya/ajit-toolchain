\ 7.7 FCode Debugging command group

\ The user interface versions of these FCode functions allow
\ the user to debug FCode programs by providing named commands 
\ corresponding to FCode functions.

: headerless    ( -- )
  ;

: headers    ( -- )
  ;

: apply    ( ... "method-name< >device-specifier< >" -- ??? )
  ;

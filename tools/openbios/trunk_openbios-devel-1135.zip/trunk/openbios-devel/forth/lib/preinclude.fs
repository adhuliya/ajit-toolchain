\ 
\ config and build date includes
\ 
\ Copyright (C) 2005 Stefan Reinauer
\ 
\ See the file "COPYING" for further information about
\ the copyright and warranty status of this work.
\ 

include config.fs
include version.fs

\ 7.4.4.2 The script

: nvedit    ( -- )
  ;
  
: nvstore    ( -- )
  ;
  
: nvquit    ( -- ) 
  ;
  
: nvrecover    ( -- )
  ;
  
: nvrun    ( -- )
  ;

\ 7.4.9    Client program callback

: callback    ( "service-name< >" "arguments<cr>" -- )
  ;
  
: $callback ( argn ... arg1 nargs addr len -- retn ... ret2 Nreturns-1 )
  ;

: sync    ( -- )
  ;

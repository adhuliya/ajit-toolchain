/*
 *   Creation Date: <2004/08/28 18:03:25 stepan>
 *   Time-stamp: <2004/08/28 18:03:25 stepan>
 *
 *	<pearpc/kernel.c>
 *
 *   Copyright (C) 2005 Stefan Reinauer
 *
 *   This program is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License
 *   version 2
 *
 */

#include "pearpc-dict.h"
#include "../kernel.c"

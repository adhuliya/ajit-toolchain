extern phandle_t pic_handle;

void ob_macio_heathrow_init(const char *path, phys_addr_t addr);
void ob_macio_keylargo_init(const char *path, phys_addr_t addr);
void macio_nvram_init(const char *path, phys_addr_t addr);

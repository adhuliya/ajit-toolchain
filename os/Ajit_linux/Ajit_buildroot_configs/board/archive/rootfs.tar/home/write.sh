#!/bin/sh

a=0

until [ $a -gt 100 ]
do
	echo 'test' > "./test/test${a}.txt"
	a=`expr $a + 1`
done
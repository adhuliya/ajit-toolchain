#!/bin/sh

a=0

until [ $a -gt 100 ]
do
	cat "./test/test${a}.txt" > /dev/null;
	a=`expr $a + 1`
done
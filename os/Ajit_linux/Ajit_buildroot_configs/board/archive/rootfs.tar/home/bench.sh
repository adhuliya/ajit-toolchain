#!/bin/sh

# # writing
# for i in {0..1000}; 
# do 
# 	echo 'test' > "./test/test${i}.txt";
# done
# # reading
# for i in {0..1000};
# do 
# 	cat "./test/test${i}.txt" > /dev/null;
# done

# a=0

# until [ $a -gt 100 ]
# do
# 	echo 'test' > "./test/test${a}.txt"
# 	a=`expr $a + 1`
# done

# until [ $a -gt 100 ]
# do
# 	cat "./test/test${a}.txt" > /dev/null;
# 	a=`expr $a + 1`
# done

time sh write.sh

time sh read.sh